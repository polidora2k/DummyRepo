import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookTest {

	public static void main(String[] args) {
		//Set property to chrome webdriver
		System.setProperty("webdriver.chrome.driver", "/Users/ipolidora/cmpsc132/chromedriver");
		
		//Create the webdriver
		WebDriver driver = new ChromeDriver();
		
		//Navigate to facebook
		driver.navigate().to("https://www.facebook.com/");
		
		//Enter the email
		driver.findElement(By.id("email")).sendKeys("batman554466@gmail.com");
		
		//Enter the password
		driver.findElement(By.id("pass")).sendKeys("password1234");
		
		//Click the login button
		driver.findElement(By.name("login")).click();
		
		//Validate that the message was displayed.
		if (!(driver.findElements(By.className("_9ay7")).isEmpty())) {
			//Print a message and quit the driver.
			System.out.println("Message Matches");
			driver.quit();
		}
	}

}
